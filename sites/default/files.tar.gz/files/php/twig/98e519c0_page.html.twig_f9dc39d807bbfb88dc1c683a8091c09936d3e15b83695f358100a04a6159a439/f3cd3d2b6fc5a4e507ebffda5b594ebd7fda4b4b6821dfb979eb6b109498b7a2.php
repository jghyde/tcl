<?php

/* themes/tcl/templates/system/page.html.twig */
class __TwigTemplate_309067190059972233e2de361dd34d463d7460c9bafde93c8dc7b1e8459241c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'navbar' => array($this, 'block_navbar'),
            'main' => array($this, 'block_main'),
            'header' => array($this, 'block_header'),
            'sidebar_first' => array($this, 'block_sidebar_first'),
            'highlighted' => array($this, 'block_highlighted'),
            'breadcrumb' => array($this, 'block_breadcrumb'),
            'action_links' => array($this, 'block_action_links'),
            'help' => array($this, 'block_help'),
            'content' => array($this, 'block_content'),
            'sidebar_second' => array($this, 'block_sidebar_second'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 59, "if" => 61, "block" => 62);
        $filters = array("clean_class" => 67);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'if', 'block'),
                array('clean_class'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 59
        $context["container"] = (($this->getAttribute($this->getAttribute(($context["theme"] ?? null), "settings", array()), "fluid_container", array())) ? ("container-fluid") : ("container"));
        // line 61
        if (($this->getAttribute(($context["page"] ?? null), "navigation", array()) || $this->getAttribute(($context["page"] ?? null), "navigation_collapsible", array()))) {
            // line 62
            echo "  ";
            $this->displayBlock('navbar', $context, $blocks);
        }
        // line 84
        echo "
";
        // line 86
        $this->displayBlock('main', $context, $blocks);
        // line 165
        echo "</div>
";
        // line 166
        if ($this->getAttribute(($context["page"] ?? null), "footer", array())) {
            // line 167
            echo "<div id=\"footer-wrapper\">
  ";
            // line 168
            $this->displayBlock('footer', $context, $blocks);
            // line 173
            echo "</div>
";
        }
    }

    // line 62
    public function block_navbar($context, array $blocks = array())
    {
        // line 63
        echo "    ";
        // line 64
        $context["navbar_classes"] = array(0 => "navbar", 1 => (($this->getAttribute($this->getAttribute(        // line 66
($context["theme"] ?? null), "settings", array()), "navbar_inverse", array())) ? ("navbar-inverse") : ("navbar-default")), 2 => (($this->getAttribute($this->getAttribute(        // line 67
($context["theme"] ?? null), "settings", array()), "navbar_position", array())) ? (("navbar-" . \Drupal\Component\Utility\Html::getClass($this->getAttribute($this->getAttribute(($context["theme"] ?? null), "settings", array()), "navbar_position", array())))) : (($context["row"] ?? null))));
        // line 70
        echo "    <header";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["navbar_attributes"] ?? null), "addClass", array(0 => ($context["navbar_classes"] ?? null)), "method"), "html", null, true));
        echo " id=\"navbar\" role=\"banner\">
      <div class=\"navbar-header\">
        ";
        // line 72
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "navigation", array()), "html", null, true));
        echo "
      </div>
      ";
        // line 75
        echo "      ";
        if ($this->getAttribute(($context["page"] ?? null), "navigation_collapsible", array())) {
            // line 76
            echo "        <div id=\"navbar-collapse\" class=\"navbar-collapse collapse\">
          ";
            // line 77
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "navigation_collapsible", array()), "html", null, true));
            echo "
            </div>
        </div>
      ";
        }
        // line 81
        echo "    </header>
  ";
    }

    // line 86
    public function block_main($context, array $blocks = array())
    {
        // line 87
        echo "<div id=\"main-wrapper\">
    <div role=\"main\"
         class=\"main-container ";
        // line 89
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["container"] ?? null), "html", null, true));
        echo " js-quickedit-main-content\">
        <div class=\"row\">

            ";
        // line 93
        echo "            ";
        if ($this->getAttribute(($context["page"] ?? null), "header", array())) {
            // line 94
            echo "                ";
            $this->displayBlock('header', $context, $blocks);
            // line 99
            echo "            ";
        }
        // line 100
        echo "
            ";
        // line 102
        echo "            ";
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_first", array())) {
            // line 103
            echo "                ";
            $this->displayBlock('sidebar_first', $context, $blocks);
            // line 108
            echo "            ";
        }
        // line 109
        echo "
            ";
        // line 111
        echo "            ";
        $context["content_classes"] = array(0 => ((($this->getAttribute(        // line 112
($context["page"] ?? null), "sidebar_first", array()) && $this->getAttribute(($context["page"] ?? null), "sidebar_second", array()))) ? ("col-sm-6") : ("")), 1 => ((($this->getAttribute(        // line 113
($context["page"] ?? null), "sidebar_first", array()) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_second", array())))) ? ("col-sm-9") : ("")), 2 => ((($this->getAttribute(        // line 114
($context["page"] ?? null), "sidebar_second", array()) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_first", array())))) ? ("col-sm-9") : ("")), 3 => (((twig_test_empty($this->getAttribute(        // line 115
($context["page"] ?? null), "sidebar_first", array())) && twig_test_empty($this->getAttribute(($context["page"] ?? null), "sidebar_second", array())))) ? ("col-sm-12") : ("")));
        // line 117
        echo "            <section";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["content_attributes"] ?? null), "addClass", array(0 => ($context["content_classes"] ?? null)), "method"), "html", null, true));
        echo ">

                ";
        // line 120
        echo "                ";
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", array())) {
            // line 121
            echo "                    ";
            $this->displayBlock('highlighted', $context, $blocks);
            // line 124
            echo "                ";
        }
        // line 125
        echo "
                ";
        // line 127
        echo "                ";
        if (($context["breadcrumb"] ?? null)) {
            // line 128
            echo "                    ";
            $this->displayBlock('breadcrumb', $context, $blocks);
            // line 131
            echo "                ";
        }
        // line 132
        echo "
                ";
        // line 134
        echo "                ";
        if (($context["action_links"] ?? null)) {
            // line 135
            echo "                    ";
            $this->displayBlock('action_links', $context, $blocks);
            // line 138
            echo "                ";
        }
        // line 139
        echo "
                ";
        // line 141
        echo "                ";
        if ($this->getAttribute(($context["page"] ?? null), "help", array())) {
            // line 142
            echo "                    ";
            $this->displayBlock('help', $context, $blocks);
            // line 145
            echo "                ";
        }
        // line 146
        echo "
                ";
        // line 148
        echo "                ";
        $this->displayBlock('content', $context, $blocks);
        // line 152
        echo "            </section>

            ";
        // line 155
        echo "            ";
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_second", array())) {
            // line 156
            echo "                ";
            $this->displayBlock('sidebar_second', $context, $blocks);
            // line 161
            echo "            ";
        }
        // line 162
        echo "        </div>
    </div>
    ";
    }

    // line 94
    public function block_header($context, array $blocks = array())
    {
        // line 95
        echo "                    <div class=\"col-sm-12\" role=\"heading\">
                        ";
        // line 96
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header", array()), "html", null, true));
        echo "
                    </div>
                ";
    }

    // line 103
    public function block_sidebar_first($context, array $blocks = array())
    {
        // line 104
        echo "                    <aside class=\"col-sm-3\" role=\"complementary\">
                        ";
        // line 105
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "sidebar_first", array()), "html", null, true));
        echo "
                    </aside>
                ";
    }

    // line 121
    public function block_highlighted($context, array $blocks = array())
    {
        // line 122
        echo "                        <div class=\"highlighted\">";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
        echo "</div>
                    ";
    }

    // line 128
    public function block_breadcrumb($context, array $blocks = array())
    {
        // line 129
        echo "                        ";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["breadcrumb"] ?? null), "html", null, true));
        echo "
                    ";
    }

    // line 135
    public function block_action_links($context, array $blocks = array())
    {
        // line 136
        echo "                        <ul class=\"action-links\">";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["action_links"] ?? null), "html", null, true));
        echo "</ul>
                    ";
    }

    // line 142
    public function block_help($context, array $blocks = array())
    {
        // line 143
        echo "                        ";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "help", array()), "html", null, true));
        echo "
                    ";
    }

    // line 148
    public function block_content($context, array $blocks = array())
    {
        // line 149
        echo "                    <a id=\"main-content\"></a>
                    ";
        // line 150
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content", array()), "html", null, true));
        echo "
                ";
    }

    // line 156
    public function block_sidebar_second($context, array $blocks = array())
    {
        // line 157
        echo "                    <aside class=\"col-sm-3\" role=\"complementary\">
                        ";
        // line 158
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "sidebar_second", array()), "html", null, true));
        echo "
                    </aside>
                ";
    }

    // line 168
    public function block_footer($context, array $blocks = array())
    {
        // line 169
        echo "    <footer class=\"footer ";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["container"] ?? null), "html", null, true));
        echo "\" role=\"contentinfo\">
      ";
        // line 170
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer", array()), "html", null, true));
        echo "
    </footer>
  ";
    }

    public function getTemplateName()
    {
        return "themes/tcl/templates/system/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  340 => 170,  335 => 169,  332 => 168,  325 => 158,  322 => 157,  319 => 156,  313 => 150,  310 => 149,  307 => 148,  300 => 143,  297 => 142,  290 => 136,  287 => 135,  280 => 129,  277 => 128,  270 => 122,  267 => 121,  260 => 105,  257 => 104,  254 => 103,  247 => 96,  244 => 95,  241 => 94,  235 => 162,  232 => 161,  229 => 156,  226 => 155,  222 => 152,  219 => 148,  216 => 146,  213 => 145,  210 => 142,  207 => 141,  204 => 139,  201 => 138,  198 => 135,  195 => 134,  192 => 132,  189 => 131,  186 => 128,  183 => 127,  180 => 125,  177 => 124,  174 => 121,  171 => 120,  165 => 117,  163 => 115,  162 => 114,  161 => 113,  160 => 112,  158 => 111,  155 => 109,  152 => 108,  149 => 103,  146 => 102,  143 => 100,  140 => 99,  137 => 94,  134 => 93,  128 => 89,  124 => 87,  121 => 86,  116 => 81,  109 => 77,  106 => 76,  103 => 75,  98 => 72,  92 => 70,  90 => 67,  89 => 66,  88 => 64,  86 => 63,  83 => 62,  77 => 173,  75 => 168,  72 => 167,  70 => 166,  67 => 165,  65 => 86,  62 => 84,  58 => 62,  56 => 61,  54 => 59,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/tcl/templates/system/page.html.twig", "/var/www/drupalvm/drupal/lightning/docroot/themes/tcl/templates/system/page.html.twig");
    }
}
